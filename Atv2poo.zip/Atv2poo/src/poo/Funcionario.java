package poo;

public class Funcionario {
	private String nome;
   
    public Funcionario(String nome) {
        this.setNome(nome);
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
