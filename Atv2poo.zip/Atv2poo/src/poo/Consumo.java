package poo;

import java.util.Date;

public class Consumo {
	private ItemFrigobar item;
    private int quantidade;
    private Date data;
    private Hospede hospede;
    
    public Consumo(ItemFrigobar item, int quantidade, Date data, Hospede hospede) {
        this.item = item;
        this.quantidade = quantidade;
        this.data = data;
        this.hospede = hospede;
    }
    
	public ItemFrigobar getItem() {
		return item;
	}
	
	public void setItem(ItemFrigobar item) {
		this.item = item;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Hospede getHospede() {
		return hospede;
	}

	public void setHospede(Hospede hospede) {
		this.hospede = hospede;
	}
}
