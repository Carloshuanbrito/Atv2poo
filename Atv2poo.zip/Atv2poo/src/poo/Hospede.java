package poo;

public class Hospede extends Pessoa{
	private int idHospede;
	private String cpfHospede;
	
	public Hospede(String nome, String telefone, int idHospede, String cpfHospede) {
		super(nome, telefone);
		this.idHospede = idHospede;
		this.cpfHospede = cpfHospede;
	}
	
	
	public int getIdHospede() {
		return idHospede;
	}
	
	public void setIdHospede(int idHospede) {
		this.idHospede = idHospede;
	}
	
	public String getCpfHospede() {
		return cpfHospede;
	}
	
	public void setCpfHospede(String cpfHospede) {
		this.cpfHospede = cpfHospede;
	}
	
	
}
