package poo;
import java.util.*;

public class Quarto {
	private int numero;
    private String categoria;
    private List<ItemFrigobar> frigobar;
    private List<Servico> servicos;

    public Quarto(int numero, String categoria) {
        this.numero = numero;
        this.categoria = categoria;
        frigobar = new ArrayList<>();
        servicos = new ArrayList<>();
        
    }

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public List<ItemFrigobar> getFrigobar() {
		return frigobar;
	}

	public void setFrigobar(List<ItemFrigobar> frigobar) {
		this.frigobar = frigobar;
	}

	public List<Servico> getServicos() {
		return servicos;
	}

	public void setServicos(List<Servico> servicos) {
		this.servicos = servicos;
	}
    
    
    
}
