package poo;

import java.util.Date;

public class ServicoSolicitado {
	private Servico servico;
    private Date data;
    private Hospede hospede;
    
    public ServicoSolicitado(Servico servico, Date data, Hospede hospede) {
    	this.servico = servico;
    	this.data = data;
    	this.hospede = hospede;
    }
    
	public Servico getServico() {
		return servico;
	}
	
	public void setServico(Servico servico) {
		this.servico = servico;
	}
	
	public Date getData() {
		return data;
	}
	
	public void setData(Date data) {
		this.data = data;
	}

	public Hospede getHospede() {
		return hospede;
	}

	public void setHospede(Hospede hospede) {
		this.hospede = hospede;
	}

   
}
