package poo;

import java.util.Date;

public class Reserva {
	private Hospede hospede;
    private Date dataReserva;
    private Date dataDesocupacao;
    private Quarto quarto;

    public Reserva(Hospede hospede, Date dataReserva, Date dataDesocupacao, Quarto quarto) {
        this.hospede = hospede;
        this.dataReserva = dataReserva;
        this.dataDesocupacao = dataDesocupacao;
        this.quarto = quarto;
    }

	public Hospede getHospede() {
		return hospede;
	}

	public void setHospede(Hospede hospede) {
		this.hospede = hospede;
	}

	public Date getDataReserva() {
		return dataReserva;
	}

	public void setDataReserva(Date dataReserva) {
		this.dataReserva = dataReserva;
	}

	public Date getDataDesocupacao() {
		return dataDesocupacao;
	}

	public void setDataDesocupacao(Date dataDesocupacao) {
		this.dataDesocupacao = dataDesocupacao;
	}

	public Quarto getQuarto() {
		return quarto;
	}

	public void setQuarto(Quarto quarto) {
		this.quarto = quarto;
	}
	
	public double calcularValorReserva(double taxaDiaria) {
        long diff = dataDesocupacao.getTime() - dataReserva.getTime();
        long dias = diff / (1000 * 60 * 60 * 24);
        return dias * taxaDiaria;
    }
}
