package poo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Hotel {
	private List<Quarto> quartos;
    private List<Hospede> hospedes;
    private List<Reserva> reservas;
    private List<Funcionario> funcionarios;
    private List<Consumo> consumos;
    private List<ServicoSolicitado> servicosSolicitados;
    private double taxaDiaria;
	
	public Hotel(double taxaDiaria) {
		this.taxaDiaria = taxaDiaria;
        quartos = new ArrayList<>();
        hospedes = new ArrayList<>();
        reservas = new ArrayList<>();
        funcionarios = new ArrayList<>();
        consumos = new ArrayList<>();
        servicosSolicitados = new ArrayList<>();
	}

	public List<Quarto> getQuartos() {
		return quartos;
	}

	public void setQuartos(List<Quarto> quartos) {
		this.quartos = quartos;
	}

	public List<Hospede> getHospedes() {
		return hospedes;
	}

	public void setHospedes(List<Hospede> hospedes) {
		this.hospedes = hospedes;
	}

	public List<Reserva> getReservas() {
		return reservas;
	}

	public void setReservas(List<Reserva> reservas) {
		this.reservas = reservas;
	}

	public List<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(List<Funcionario> funcionarios) {
		this.funcionarios = funcionarios;
	}

	public List<Consumo> getConsumos() {
		return consumos;
	}

	public void setConsumos(List<Consumo> consumos) {
		this.consumos = consumos;
	}

	public List<ServicoSolicitado> getServicosSolicitados() {
		return servicosSolicitados;
	}

	public void setServicosSolicitados(List<ServicoSolicitado> servicosSolicitados) {
		this.servicosSolicitados = servicosSolicitados;
	}

	public double getTaxaDiaria() {
		return taxaDiaria;
	}

	public void setTaxaDiaria(double taxaDiaria) {
		this.taxaDiaria = taxaDiaria;
	}
	
	public void adicionarConsumo(ItemFrigobar item, int quantidade, Date data, Hospede hospede) {
        Consumo consumo = new Consumo(item, quantidade, data, hospede);
        consumos.add(consumo);
    }
	
	public void solicitarServico(Servico servico, Date data, Hospede hospede) {
        ServicoSolicitado servicoSolicitado = new ServicoSolicitado(servico, data, hospede);
        servicosSolicitados.add(servicoSolicitado);
    }

}
