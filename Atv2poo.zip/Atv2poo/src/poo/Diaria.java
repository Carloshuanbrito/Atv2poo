package poo;

import java.util.Date;

public class Diaria {
	private Quarto quarto;
    private Date data;
    private Hospede pagador;
    private Funcionario funcionarioResponsavel;
    
    public Diaria(Quarto quarto, Date data, Hospede pagador, Funcionario funcionarioResponsavel) {
        this.quarto = quarto;
        this.data = data;
        this.pagador = pagador;
        this.funcionarioResponsavel = funcionarioResponsavel;
    }
    
	public Quarto getQuarto() {
		return quarto;
	}
	
	public void setQuarto(Quarto quarto) {
		this.quarto = quarto;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Hospede getPagador() {
		return pagador;
	}

	public void setPagador(Hospede pagador) {
		this.pagador = pagador;
	}

	public Funcionario getFuncionarioResponsavel() {
		return funcionarioResponsavel;
	}

	public void setFuncionarioResponsavel(Funcionario funcionarioResponsavel) {
		this.funcionarioResponsavel = funcionarioResponsavel;
	}
}
